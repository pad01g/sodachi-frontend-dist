import{W as n}from"./index-BpANH3lH.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
