import{W as n}from"./index-Bi2izEgE.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
